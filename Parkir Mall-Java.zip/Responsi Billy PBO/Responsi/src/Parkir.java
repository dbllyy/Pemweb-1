import java.util.Scanner;
// 
public class Parkir {
	protected String NamaKendaraan, tipe;
	protected int BiayaParkir, jam,kode;

	// method konstruktor
	public Parkir(int kda, String nma, int by){ 
		kode = kda;
		NamaKendaraan = nma;
		BiayaParkir = by;
	}
	
		// overloading (nama method yang sama tapi parameter berbeda)
	protected void strukparkir(){
		System.out.println("--------------------------------------");
		System.out.println("Kode                   : " + kode);
	  System.out.println("Jenis Kendaraan        : " + NamaKendaraan);
	  System.out.println("Biaya                  : " + BiayaParkir);
	}

		//override (nama method yang sama dan parameter sama)
	protected void strukparkir(int jam){
    @SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		this.jam=jam;
		System.out.print("Berapa Jam  : ");
		jam = scan.nextInt();
		System.out.println("--------------------------------------");
	    int sum = 0;
		for(int i=0; i<jam; i++) {
			sum+=BiayaParkir;
	    }
	    System.out.println("Total Biaya Parkir  "+sum);
	}
}	

// pewarisan parkir ke mobil subclass
class mobil extends Parkir{
	protected int jam, ket;
	protected String tipe;
	protected mobil(int kda,  String nma, int by) {
				super(kda, nma, by);
		}   
		//Pemanggilan Overriding
		@Override
		protected void strukparkir() {
			super.strukparkir();
			@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.print("Mobil Tipe	       : ");
		tipe = scan.next();
		System.out.print("Berapa Jam 	       : ");
		jam = scan.nextInt();
		System.out.print("Jumlah Kedaraan        : ");
		ket = scan.nextInt();
		System.out.println("--------------------------------------");
			int sum = 0;
			int hasil = ket * jam;
		for(int i=0; i<hasil; i++) {
			sum+=BiayaParkir;
			}
			System.out.println("Total Biaya Parkir  "+sum);
		}
}

// pewarisan parkir ke motor
class motor extends Parkir{
	protected int jam;
	protected int ket;
	protected String tipe;
	protected motor(int kda,  String nma, int by) {
				super(kda, nma, by);
		}   
		//Pemanggilan Overriding
		@Override
		protected void strukparkir() {
		super.strukparkir();
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.print("Motor Tipe	       : ");
		tipe = scan.next();
		System.out.print("Berapa Jam 	       : ");
		jam = scan.nextInt();
		System.out.print("Jumlah Kedaraan        : ");
		ket = scan.nextInt();
		System.out.println("--------------------------------------");
			int sum = 0;
			int hasil = ket * jam;
		for(int i=0; i<hasil; i++) {
			sum+=BiayaParkir;
			}
			System.out.println("Total Biaya Parkir  "+sum);
		}
}

// pewarisan
class truk extends Parkir{
	protected int jam;
	protected int ket;
	protected String tipe;
	protected truk(int kda,  String nma, int by) {
				super(kda, nma, by);
		}   
		//Pemanggilan Overriding
		@Override
		protected void strukparkir() {
		super.strukparkir();
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.print("Truk Tipe	       : ");
		tipe = scan.next();
		System.out.print("Berapa Jam 	       : ");
		jam = scan.nextInt();
		System.out.print("Jumlah Kedaraan        : ");
		ket = scan.nextInt();
		System.out.println("--------------------------------------");
			int sum = 0;
			int hasil = ket * jam;
		for(int i=0; i<hasil; i++) {
			sum+=BiayaParkir;
			}
			System.out.println("Total Biaya Parkir  "+sum);
		}
}



