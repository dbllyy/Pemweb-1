import java.util.*;  

// class ini digunakan untuk bagian main, atau untuk me run program
public class CetakParkir {

    int id;
    String nama, harga;
    CetakParkir next;
    public static Scanner in = new Scanner(System.in);
    public static Scanner str = new Scanner(System.in);

    public void input() {
        System.out.print("Masukkan id               : ");
        id = in.nextInt();
        System.out.print("Masukkan Nama Jenis Kendaraan : ");
        nama = str.nextLine();
        System.out.print("Masukkan Harga Parkir Perjam : ");
        harga = str.nextLine();
        next = null;
    }

    public void view() {
        System.out.println("| " + id + " | " + nama + " | " + harga + " |");
    }
       
    /**
     * 
     */
    public static void main() {

        int menu = 0, del;
        final linkedlist ll = new linkedlist();
        while (menu != 4) {
            System.out.print("1.Input\n2.View\n3.Delete\n4.Exit : \n");
            System.out.print("Masukan Pilihan Menu :");
            menu = in.nextInt();
            if (menu == 1)
                ll.add();
            else if (menu == 2)
                ll.view();
            else if (menu == 3) {
                System.out.print("1.Data Pertama\n2.Data Terkahir\n : ");
                del = in.nextInt();
                if (del == 1)
                    ll.removeFirst();
                else if (del == 2)
                    ll.removeLast();
                else
                    System.out.println("Salah");
            } else if (menu == 4)
                System.out.println("Keluar");
            else
                System.out.println("Salah");
            System.out.println();
        }
    }





    public static void main(String[] args) {
        int x;
        int c;
        @SuppressWarnings("resource")
        Scanner scan = new Scanner(System.in);
        System.out.println("------------------------------------------------");
        System.out.println("==============Parkir RS Doris sylvanus==========");
        System.out.println("------------------------------------------------");
        System.out.println("1. Mobil                                        ");
        System.out.println("2. Truk                                         ");
        System.out.println("3. Motor                                        ");
        System.out.println("4. Menambahkan Data Baru                        ");
        System.out.println("5. Exit                                         ");
        System.out.println("------------------------------------------------");

        // Polymorphism atau Polimorfisme pemanggilan dengan memasukan data di dalamnya
        // :
        Parkir mbl = new mobil(1, "Mobil", 10000);
        Parkir mtr = new motor(2, "Motor", 5000);
        Parkir trk = new truk(3, "Truk", 15000);

        System.out.print("Tambahkan Jumlah Jenis Kendaraan Yang Dipilih : ");
        x = scan.nextInt();
        // do while
        // i = nilai awal = 0
        for (int i = 0; i < x; i++) {
            System.out.println("______________________________________________________");
            System.out.print("\nKetik Nomor Barang Yang Akan Dipilih : ");
            c = scan.nextInt();
            switch (c) {
                case 1:
                    // memanggil method override dengan isian data yg sudah di deklrasi
                    mbl.strukparkir();
                    break;
                case 2:
                    trk.strukparkir();
                    break;
                case 3:
                    mtr.strukparkir();
                    break;
                case 4:
                    main();
                    break;
                case 5:
                    System.out.println("Terima Kasih");
                    System.exit(0);
                default:
                    System.out.println("Menu Tidak Ada");
            }
        }
    }
}

class linkedlist {
    CetakParkir head, tail;

    public linkedlist() {
        head = null;
        tail = null;
    }

    public void add() {
        CetakParkir baru = new CetakParkir();
        baru.input();
        if (head == null)
            head = baru;
        else
            tail.next = baru;
        tail = baru;
    }

    public void view() {
        if (head == null) {
            System.out.println("Kosong");
            return;
        }
        System.out.println("| Id | Nama | harga |");
        CetakParkir ptr = head;
        while (ptr != null) {
            ptr.view();
            ptr = ptr.next;
        }
    }

    public void removeFirst() {
        if (head == null) {
            System.out.println("Kosong");
            return;
        }
        System.out.println("Data " + head.nama + " Berhasil Dihapus");
        head = head.next;
    }

    public void removeLast() {
        if (head == null) {
            System.out.println("Kosong");
            return;
        }
        System.out.println("Data " + tail.nama + " Berhasil Dihapus");
        if (head == tail) {
            head = null;
            tail = null;
        } else {
            CetakParkir ptr = head.next;
            CetakParkir prev = head;
            while (ptr != tail) {
                ptr = ptr.next;
                prev = prev.next;
            }
            prev.next = null;
            tail = prev;
        }
    }
}