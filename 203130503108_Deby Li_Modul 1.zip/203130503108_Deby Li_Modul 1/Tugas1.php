<?php
    // mendeklarasiakan masukan data pada array
    $names= ["Dessy", "Yuli", "Melda", "Neli", "Christin", "Deby Li"];
    ?>
  
 <!-- // menampilkan semua data pada array menggunakan perulangan foreach -->
 <!-- // forech adalah salah satu syntax php yang digunakan pada array -->
           <?php foreach ($names as $name) :  ?>

                    <tr>
                        <td><?php echo $name."<br>"; ?></td>
                    </tr>            
	                  <?php endforeach; ?>   
           
<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- membuat title di atas webnya -->
  <title>Modul 1</title>
  <!-- judul -->
  <h1>Tugas Laporan Modul 1</h1>
  
</head>
<body>
    <!-- Membuat tabel untuk Tempat Nama -->
      <table bgcolor="white" border="1" cellpadding="10" cellspacing="1">
          <thead>
            <tr>
               <th>Nama</th>
            </tr>
          </thead>
      </table>
                
</body>
</html>
